import scrapy
import re
import json
import time
import os
from pathlib import Path
from dotenv import load_dotenv
from publication_scraper.items import PublicationItem

# Charger les variables d'environnement
env_path = Path(__file__).parent.parent.parent / '.env'
load_dotenv(dotenv_path=env_path)


class TribunaSpider(scrapy.Spider):
    """
    Spider pour extraire les publications des sites Tribuna (Fribourg, Graubünden, etc.)
    
    Basé sur le modèle tribuna.py du client, utilise POST requests directes
    au lieu de Playwright pour parser les réponses GWT.
    
    Usage:
        # Scraping initial (toutes les décisions)
        scrapy crawl tribuna -a canton=fribourg
        
        # Scraping incrémental (depuis une date)
        scrapy crawl tribuna -a canton=fribourg -a ab=2024-11-01
    """
    name = 'tribuna'
    
    # Regex pour parser les réponses GWT (inspiré de tribuna.py)
    reVor = re.compile(r'//OK\[[0-9,\.]+\[')
    reAll = re.compile(r'(?<=,\")[^\"]*(?:\\\"[^\"]*)*(?=\",)')
    reID = re.compile(r'[0-9a-f]{32}|[0-9]{15,17}')
    reDatum = re.compile(r'\d{4}-\d{2}-\d{2}')
    reRG = re.compile(r'[^0-9\.:-]{3}.{3,}')
    reTreffer = re.compile(r'(?<=^//OK\[)[0-9]+')
    reDecrypt = re.compile(r'(?<=//OK\[1,\[")[0-9a-f]+')
    reDecrypt2 = re.compile(r'(?<=//OK)([0-9,"a-z.A-Z/\[\]]+partURL\",\")(?P<p1>[^"]+_)(?P<p2>[^"_]+)","(?P<p3>dossiernummer)","(?P<p4>[^"]+)')
    rePfad = re.compile(r'[A-Z]:(?:\\.+)+\.pdf')
    rePfad2 = re.compile(r'[0-9a-f]{128,192}')
    reDecode = re.compile(r'\\x([0-9A-Fa-f]{2})')
    reNum = re.compile(r'.+')  # Regex pour numéro de dossier (à adapter selon canton)
    
    # Compteurs
    page_nr = 0
    trefferzahl = 0
    
    def __init__(self, canton='fribourg', ab=None, *args, **kwargs):
        """
        Initialisation du spider
        
        Args:
            canton: Nom du canton (fribourg, graubunden, etc.)
            ab: Date de début pour scraping incrémental (format YYYY-MM-DD)
        """
        super(TribunaSpider, self).__init__(*args, **kwargs)
        
        # Charger la configuration du canton
        config_path = Path(__file__).parent.parent / 'cantons_config.json'
        with open(config_path, 'r', encoding='utf-8') as f:
            configs = json.load(f)
        
        if canton not in configs:
            raise ValueError(f"Canton '{canton}' non trouvé dans la configuration. Cantons disponibles: {list(configs.keys())}")
        
        self.config = configs[canton]
        self.canton = canton
        self.kanton_kurz = self.config['kanton_kurz']
        self.ab = ab or os.getenv('START_DATE', None)
        
        # URLs et configuration
        self.RESULT_PAGE_URL = self.config['result_page_url']
        self.DECRYPT_PAGE_URL = self.config['decrypt_page_url']
        self.COOKIE_INIT = self.config.get('cookie_init_url')
        self.DOWNLOAD_URL = self.config['download_url']
        self.PDF_PATH = self.config['pdf_path']
        
        # Templates de requête
        self.RESULT_QUERY_TPL = self.config['result_query_tpl']
        self.RESULT_QUERY_TPL_AB = self.config['result_query_tpl_ab']
        self.DECRYPT_START = self.config['decrypt_start']
        self.DECRYPT_END = self.config['decrypt_end']
        self.PDF_PATTERN = self.config['pdf_pattern']
        
        # Flags
        self.ENCRYPTED = self.config['encrypted']
        self.ASCII_ENCRYPTED = self.config['ascii_encrypted']
        self.COOKIE = self.config['needs_cookie']
        self.HOLE_AUCH_HTML = self.config['hole_auch_html']
        self.MAX_PAGES = self.config.get('max_pages', int(os.getenv('MAX_PAGES', 20000)))
        
        # Headers
        self.HEADERS = self.config['headers']
        
        # Allowed domains
        domain = self.config['base_url'].replace('https://', '').replace('http://', '').rstrip('/')
        self.allowed_domains = [domain]
        
        self.logger.info(f"Spider initialisé pour {self.config['name']} ({self.kanton_kurz})")
        if self.ab:
            self.logger.info(f"Mode incrémental: scraping depuis {self.ab}")
        else:
            self.logger.info("Mode initial: scraping complet")

        # Anti-doublons par DocId (pour éviter les répétitions entre pages/réponses)
        self.seen_ids = set()
    
    def start_requests(self):
        """Génère la première requête"""
        body = self.get_next_request()
        
        if self.COOKIE:
            # Initialiser le cookie d'abord
            orequest = scrapy.Request(
                url=self.RESULT_PAGE_URL,
                method="POST",
                body=body,
                headers=self.HEADERS,
                callback=self.parse_page,
                errback=self.errback_httpbin,
                dont_filter=True
            )
            request = scrapy.Request(
                url=self.COOKIE_INIT,
                headers=self.HEADERS,
                callback=self.set_cookie,
                errback=self.errback_httpbin,
                meta={'request': orequest, 'referrer_policy': "no-referrer"},
                dont_filter=True
            )
            yield request
        else:
            # Requête directe sans cookie
            yield scrapy.Request(
                url=self.RESULT_PAGE_URL,
                method="POST",
                body=body,
                headers=self.HEADERS,
                callback=self.parse_page,
                errback=self.errback_httpbin,
                meta={'referrer_policy': "no-referrer"},
                dont_filter=True
            )
    
    def get_next_request(self):
        """Génère le body de la prochaine requête"""
        self.logger.info(f"Génération requête pour page {self.page_nr}")
        millis = str(int(time.time() * 1000))
        
        if self.ab is None:
            body = self.RESULT_QUERY_TPL.format(page_nr=self.page_nr, millis=millis)
        else:
            body = self.RESULT_QUERY_TPL_AB.format(page_nr=self.page_nr, millis=millis, datum=self.ab)
        
        self.page_nr += 1
        return body
    
    def set_cookie(self, response):
        """Gère l'initialisation du cookie si nécessaire"""
        self.logger.info(f"Initialisation cookie pour {self.COOKIE_INIT}")
        
        if response.status == 200:
            self.logger.info(f"Headers reçus: {response.headers}")
            cookie = response.headers.get('Set-Cookie')
            
            if cookie:
                cookie = cookie.decode('ascii').split(';')[0].encode('ascii')
                request = response.meta['request']
                request.headers['Cookie'] = cookie
                self.logger.info(f"Cookie défini, lancement requête avec cookie")
                yield request
            else:
                self.logger.warning("Aucun cookie reçu, tentative sans cookie")
                yield response.meta['request']
        else:
            self.logger.error(f"Erreur initialisation cookie: status {response.status}")
    
    def parse_page(self, response):
        """Parse une page de résultats GWT"""
        self.logger.info(f"Parsing page {self.page_nr - 1}")
        self.logger.debug(f"Requête: {response.request.body.decode('utf-8')[:200]}")
        
        if response.status == 200 and len(response.body) > 148:  # MINIMUM_PAGE_LEN
            # Extraire le nombre total de résultats
            if self.page_nr == 1:
                treffer = self.reTreffer.search(response.text)
                if treffer:
                    self.trefferzahl = int(treffer.group())
                    self.logger.info(f"Nombre total de résultats: {self.trefferzahl}")
            
            if self.trefferzahl > 0:
                # Nettoyer la réponse GWT
                content = self.reVor.sub('', response.text)
                self.logger.debug(f"Contenu nettoyé: {content[:500]}")
                
                # Extraire les valeurs avec regex
                werte = self.reAll.findall(content)

                if len(werte) < 9:
                    self.logger.warning(f"Résultats insuffisants ({len(werte)} valeurs), page ignorée")
                else:
                    # Nouvelle logique: traiter plusieurs lignes par page en se basant sur les positions des DocId
                    yielded_this_page = 0
                    id_indexes = []
                    for i, v in enumerate(werte):
                        if self.reID.fullmatch(v or ''):
                            id_indexes.append(i)

                    if not id_indexes:
                        self.logger.warning("Aucun DocId détecté sur cette page")
                    else:
                        self.logger.debug(f"DocIds détectés: {len(id_indexes)} (premiers index: {id_indexes[:5]})")

                    # Par heuristique, une page UI affiche ~20 lignes; on limite à 20 par page
                    for idx in id_indexes[:20]:
                        try:
                            doc_id = werte[idx]
                        except Exception:
                            continue

                        # Déduplication globale par DocId
                        if doc_id in self.seen_ids:
                            continue
                        self.seen_ids.add(doc_id)

                        # Construire une vue locale plus large autour de l'ID pour absorber les décalages
                        # Certains champs (leitsatz avec highlights) décalent les positions; élargir la fenêtre
                        start = max(0, idx - 6)
                        end = min(len(werte), idx + 24)
                        slice_werte = werte[start:end]

                        parsed = self.parse_result_row(slice_werte, content)

                        # parse_result_row peut retourner: None | Request | Item | Iterable
                        if hasattr(parsed, '__iter__') and not isinstance(parsed, (dict, scrapy.Request)):
                            for r in parsed:
                                yielded_this_page += 1
                                yield r
                        elif parsed:
                            yielded_this_page += 1
                            yield parsed

                    if yielded_this_page == 0:
                        self.logger.info("Aucune ligne exploitable trouvée sur la page (après déduplication)")
            else:
                self.logger.warning("0 résultats trouvés")
            
            # Pagination
            if self.page_nr < min(self.trefferzahl, self.MAX_PAGES):
                body = self.get_next_request()
                yield scrapy.Request(
                    url=self.RESULT_PAGE_URL,
                    method="POST",
                    body=body,
                    headers=self.HEADERS,
                    callback=self.parse_page,
                    errback=self.errback_httpbin,
                    dont_filter=True
                )
            else:
                self.logger.info(f"Fin du scraping: {self.page_nr - 1} pages traitées")
        else:
            self.logger.error(f"Réponse invalide: status={response.status}, len={len(response.body)}")
    
    def parse_result_row(self, werte, content):
        """
        Parse une ligne de résultat GWT
        
        Args:
            werte: Liste des valeurs extraites par regex
            content: Contenu brut pour debug
            
        Returns:
            PublicationItem ou None si parsing échoué
        """
        try:
            korrektur = 0
            brauchbar = True

            # Extraire l'ID dynamiquement dans la fenêtre
            id_pos = None
            for i in range(min(len(werte), 12)):
                if self.reID.fullmatch(werte[i] or ''):
                    id_pos = i
                    break
            if id_pos is None:
                self.logger.error(f"ID non trouvé dans {werte[:12]}")
                return None
            id_ = werte[id_pos]

            # Kammer virtuelle (si présente juste avant l'ID)
            vkammer = ""
            if id_pos - 1 >= 0 and len(werte[id_pos - 1]) > 8 and not self.reDatum.fullmatch(werte[id_pos - 1]):
                vkammer = werte[id_pos - 1]

            # Titre à l'index suivant l'ID
            titel_idx = id_pos + 1
            titel = werte[titel_idx].replace("\\x27", "'") if titel_idx < len(werte) else ""
            if len(titel) < 8:
                self.logger.warning(f"Titre trop court: '{titel}'")
                titel = ""

            # Numéro de dossier juste après le titre
            num = None
            base_num_idx = id_pos + 2
            candidates_num = [base_num_idx, base_num_idx + 1, base_num_idx - 1]
            for ni in candidates_num:
                if 0 <= ni < len(werte) and self.reNum.fullmatch(werte[ni]):
                    num = werte[ni]
                    break
            if not num:
                self.logger.error(f"Numéro dossier non trouvé: {werte[max(0, base_num_idx-2):min(len(werte), base_num_idx+3)]}")
                return None

            # Date de décision (robuste): relative à l'ID
            entscheiddatum = None
            base_date_idx = id_pos + 3
            if base_date_idx < len(werte) and self.reDatum.fullmatch(werte[base_date_idx]):
                entscheiddatum = werte[base_date_idx]
            elif base_date_idx + 1 < len(werte) and self.reDatum.fullmatch(werte[base_date_idx + 1]):
                entscheiddatum = werte[base_date_idx + 1]
            else:
                for off in range(0, min(10, len(werte))):
                    idxd = base_date_idx + off
                    if idxd < len(werte) and self.reDatum.fullmatch(werte[idxd]):
                        entscheiddatum = werte[idxd]
                        break
                if not entscheiddatum:
                    self.logger.error(f"Date décision non trouvée autour de l'ID: {werte[max(0, base_date_idx-2):min(len(werte), base_date_idx+8)]}")
                    return None

            # Leitsatz généralement après la date
            leitsatz_idx = base_date_idx + 1
            leitsatz = werte[leitsatz_idx].replace("\\x27", "'") if leitsatz_idx < len(werte) else ""
            if len(leitsatz) < 11 or leitsatz == '-':
                leitsatz = ""

            # Pfad PDF (chercher dans les champs suivants)
            neuePfadsyntax = False
            pfad = None
            for offset in range(6):
                idx = base_date_idx + 2 + offset
                if idx < len(werte):
                    if self.rePfad.fullmatch(werte[idx]):
                        pfad = werte[idx]
                        korrektur += offset
                        break
                    elif self.rePfad2.fullmatch(werte[idx]):
                        pfad = werte[idx]
                        korrektur += offset
                        neuePfadsyntax = True
                        break
            
            if not pfad:
                self.logger.error(f"Pfad PDF non trouvé: {werte[8+korrektur:12+korrektur]}")
                return None
            
            # Date de publication
            l = len(werte)
            if neuePfadsyntax and l > 22:
                l = l - 8

            publikationsdatum = ""
            found_pub = False
            for ti in [l - 1, l - 2]:
                if 0 <= ti < len(werte) and self.reDatum.fullmatch(werte[ti]):
                    publikationsdatum = werte[ti]
                    found_pub = True
                    break
            if not found_pub and pfad is not None:
                start_pub_idx = base_date_idx + 2
                for off in range(0, 6):
                    idxp = start_pub_idx + off
                    if idxp < len(werte) and self.reDatum.fullmatch(werte[idxp]):
                        publikationsdatum = werte[idxp]
                        break
            
            # Rechtsgebiet
            rechtsgebiet = ""
            for ri in [leitsatz_idx + 1, leitsatz_idx + 2]:
                if ri < len(werte) and self.reRG.fullmatch(werte[ri]):
                    rechtsgebiet = werte[ri]
                    break
            
            # Créer l'item
            numstr = num.replace(" ", "_")
            
            item = PublicationItem()
            item['Kanton'] = self.kanton_kurz
            item['DocId'] = id_
            item['Num'] = num
            item['Titel'] = titel
            item['Leitsatz'] = leitsatz
            item['EDatum'] = entscheiddatum
            item['PDatum'] = publikationsdatum
            item['Rechtsgebiet'] = rechtsgebiet
            item['VKammer'] = vkammer
            item['Raw'] = content
            item['PageNr'] = self.page_nr - 1
            
            # Gestion du PDF (avec décryptage si nécessaire)
            if self.ENCRYPTED:
                # Préparer le pfad pour décryptage
                if neuePfadsyntax:
                    pfad_encrypt = f"{numstr}_{pfad}|dossiernummer|{numstr}"
                elif self.ASCII_ENCRYPTED:
                    ascii_pfad = ''
                    for c in pfad:
                        ascii_pfad += '|' + str(ord(c))
                    pfad_encrypt = ascii_pfad.replace("|92|92", "|92")
                else:
                    pfad_encrypt = pfad
                
                # Créer une requête de décryptage
                body = self.DECRYPT_START + pfad_encrypt + self.DECRYPT_END
                
                yield scrapy.Request(
                    url=self.DECRYPT_PAGE_URL,
                    method="POST",
                    body=body,
                    headers=self.HEADERS,
                    callback=self.decrypt_path,
                    errback=self.errback_httpbin,
                    meta={"item": item},
                    dont_filter=True
                )
                return None  # Item sera yielded après décryptage
            else:
                # PDF direct sans décryptage
                href = self.PDF_PATTERN.format(
                    self.DOWNLOAD_URL,
                    numstr,
                    id_,
                    self.PDF_PATH,
                    id_,
                    numstr
                )
                item['PDFUrls'] = [href]
                return item
                
        except Exception as e:
            self.logger.error(f"Erreur parsing résultat: {e}", exc_info=True)
            return None
    
    def decrypt_path(self, response):
        """Décrypte le chemin PDF"""
        item = response.meta['item']
        
        self.logger.info(f"Décryptage PDF pour DocID {item['DocId']}")
        
        if response.status == 200:
            self.logger.debug(f"Réponse decrypt: {response.text[:200]}")
            # Dump brut de la réponse de décryptage pour analyse (facile à consulter)
            try:
                out_dir = Path(__file__).parent.parent / 'output' / 'debug_decrypts'
                out_dir.mkdir(parents=True, exist_ok=True)
                fname = out_dir / f"decrypt_{item['DocId']}.txt"
                with open(fname, 'w', encoding='utf-8') as fh:
                    fh.write(response.text)
                self.logger.info(f"Réponse decrypt sauvegardée: {fname}")
            except Exception as _e:
                self.logger.warning(f"Impossible de sauvegarder réponse decrypt: {_e}")
            
            # Extraire un token partURL si présent (format observé: ..., "partURL","<val>", ...)
            import re as _re
            pm = _re.search(r'"partURL"\s*,\s*"([^"\\]+)"', response.text)
            part = None
            if pm:
                part = pm.group(1)

            # Fallbacks: essayer les regex existantes si l'extraction simple échoue
            if part:
                # Construire d'abord les URLs ServletDownload validées (Firecrawl)
                #  Pattern: /tribunavtplus/ServletDownload/{dossiernummer}_{hash}[.pdf]?path={hash}&pathIsEncrypted=1&dossiernummer={dossiernummer}
                #  - dossiernummer: item['Num'] (espaces -> underscores) ou valeur du decrypt si disponible
                #  - hash: dernière portion de partURL après le dernier underscore
                from urllib.parse import urlencode
                dossier_from_item = (item.get('Num') or '').replace(' ', '_')
                dm = _re.search(r'"dossiernummer"\s*,\s*"([^"\\]+)"', response.text)
                dossier = dm.group(1) if dm else dossier_from_item
                # Extraire le hash (dernier segment après '_')
                try:
                    hash_token = part.rsplit('_', 1)[-1]
                except Exception:
                    hash_token = part

                qs = urlencode({
                    'path': hash_token,
                    'pathIsEncrypted': '1',
                    'dossiernummer': dossier
                })

                base_dl = self.DOWNLOAD_URL.rstrip('/')
                servlet_candidates = [
                    f"{base_dl}/tribunavtplus/ServletDownload/{dossier}_{hash_token}?{qs}",
                    f"{base_dl}/tribunavtplus/ServletDownload/{dossier}_{hash_token}.pdf?{qs}",
                ]

                # Construire une liste d'endpoints candidats additionnels (même approche que v4/test_search)
                base = self.config.get('base_url', '').rstrip('/')
                if not base:
                    base = self.DOWNLOAD_URL.rstrip('/')

                # Build list of candidates from partURL
                candidates = list(servlet_candidates)
                code2 = self.reDecrypt2.search(response.text)
                if code2:
                    part = (code2.group("p1") + code2.group("p2"))

            if part:
                # Construire une liste d'endpoints candidats (même approche que v4/test_search)
                base = self.config.get('base_url', '').rstrip('/')
                if not base:
                    base = self.DOWNLOAD_URL.rstrip('/')

                # Build list of candidates from partURL (keep existing ServletDownload first)
                candidates = list(candidates)
                # Add path-like candidates derived from partURL when it contains underscore-separated segments
                try:
                    parts = part.split('_')
                except Exception:
                    parts = []

                if len(parts) >= 4:
                    # common pattern: /tribunavtplus/pdf/<num>/<year>/<no>/<hash>.pdf
                    candidates.extend([
                        f"{base}/tribunavtplus/pdf/{parts[0]}/{parts[1]}/{parts[2]}/{parts[3]}.pdf",
                        f"{base}/pdf/{parts[0]}/{parts[1]}/{parts[2]}/{parts[3]}.pdf",
                        f"{self.DOWNLOAD_URL.rstrip('/')}/tribunavtplus/pdf/{parts[0]}/{parts[1]}/{parts[2]}/{parts[3]}.pdf",
                        f"{self.DOWNLOAD_URL.rstrip('/')}/pdf/{parts[0]}/{parts[1]}/{parts[2]}/{parts[3]}.pdf",
                    ])

                # Keep existing query-param style fallbacks, plus additional endpoints and URL-encoded variants
                try:
                    from urllib.parse import quote
                    part_enc = quote(part, safe='')
                except Exception:
                    part_enc = part

                candidates.extend([
                    f"{base}/tribunavtplus/download?partURL={part}",
                    f"{base}/tribunavtplus/download?partURL={part_enc}",
                    f"{base}/tribunavtplus/pdf?partURL={part}",
                    f"{base}/tribunavtplus/pdf?partURL={part_enc}",
                    f"{base}/tribunavtplus/document?partURL={part}",
                    f"{base}/tribunavtplus/document?partURL={part_enc}",
                    f"{base}/tribunavtplus/getFile?partURL={part}",
                    f"{base}/tribunavtplus/getFile?partURL={part_enc}",
                    f"{base}/tribunavtplus/serve?partURL={part}",
                    f"{base}/tribunavtplus/serve?partURL={part_enc}",
                    f"{base}/tribunavtplus/publikation?download=true&partURL={part}",
                    f"{base}/tribunavtplus/publikation?download=true&partURL={part_enc}",
                    # direct fallback: try base + part
                    f"{base}/{part}",
                ])

                # Lancer la vérification des candidats (vérifier content-type/pdf)
                # On envoie la première requête avec meta contenant la liste et l'item
                first = candidates.pop(0)
                self.logger.debug(f"Premier candidat PDF: {first}")
                # include GWT headers and allow non-200 responses to be handled in callback
                hdrs = dict(self.HEADERS)
                hdrs.update({'Referer': self.HEADERS.get('Referer', '')})
                yield scrapy.Request(
                    url=first,
                    method="GET",
                    headers=hdrs,
                    callback=self.verify_pdf_candidate,
                    errback=self.errback_httpbin,
                    meta={"item": item, "candidates": candidates, 'handle_httpstatus_all': True},
                    dont_filter=True
                )
                return

            self.logger.error(f"Impossible de décrypter le PDF pour {item['DocId']}")
            # Yield l'item sans PDF plutôt que de le perdre
            item['PDFUrls'] = []
            yield item
        else:
            self.logger.error(f"Erreur décryptage: status={response.status}")
            item['PDFUrls'] = []
            yield item

    def verify_pdf_candidate(self, response):
        """Vérifie si la réponse est un PDF; sinon teste le candidat suivant."""
        item = response.meta.get('item')
        candidates = response.meta.get('candidates', [])

        # Considérer OK si status 200 et content-type indique PDF, ou si l'URL finit par .pdf
        ct = None
        try:
            ct = response.headers.get('Content-Type') or response.headers.get(b'Content-Type')
            if isinstance(ct, bytes):
                ct = ct.decode('utf-8', errors='ignore')
        except Exception:
            ct = None

        ok = (response.status == 200) and (ct and 'pdf' in ct.lower() or str(response.url).lower().endswith('.pdf'))

        if ok:
            # URL valide — retourner l'item
            item['PDFUrls'] = [response.url]
            self.logger.info(f"PDF trouvé: {response.url} (content-type={ct})")
            yield item
            return

        # Sinon, essayer le candidat suivant s'il existe
        if candidates:
            next_url = candidates.pop(0)
            self.logger.debug(f"Candidat PDF suivant: {next_url}")
            hdrs = dict(self.HEADERS)
            hdrs.update({'Referer': self.HEADERS.get('Referer', '')})
            yield scrapy.Request(
                url=next_url,
                method="GET",
                headers=hdrs,
                callback=self.verify_pdf_candidate,
                errback=self.errback_httpbin,
                meta={"item": item, "candidates": candidates, 'handle_httpstatus_all': True},
                dont_filter=True
            )
            return

        # Aucun candidat valide
        self.logger.warning(f"Aucun endpoint PDF valide trouvé pour {item['DocId']}")
        item['PDFUrls'] = []
        yield item
    
    def errback_httpbin(self, failure):
        """Gestion des erreurs HTTP"""
        self.logger.error(f"Erreur requête: {failure.value}")
